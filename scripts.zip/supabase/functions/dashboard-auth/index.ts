import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

serve(async (req) => {
  const { action, email, password, display_name, user_id } = await req.json();
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
  };

  if (req.method === "OPTIONS")
    return new Response(null, { headers: { ...cors, "Access-Control-Allow-Headers": "*" } });

  // ── REGISTER ─────────────────────────────────────────────────────────────
  if (action === "register") {
    // 1. Check whitelist
    const { data: allowed } = await supabaseAdmin
      .from("dashboard_allowed_users")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (!allowed) {
      return new Response(JSON.stringify({ error: "Email not allowed to register." }), { status: 403, headers: cors });
    }

    // 2. Check if already has a dashboard_profile (duplicate registration)
    const { data: existingProfile } = await supabaseAdmin
      .from("dashboard_profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (existingProfile) {
      return new Response(JSON.stringify({ error: "Already registered in Dashboard Manager." }), { status: 409, headers: cors });
    }

    // 3. Try to find existing auth user by email
    const { data: { users } } = await supabaseAdmin.auth.admin.listUsers();
    const existingAuthUser = users.find((u) => u.email === email);

    let authUserId: string;

    if (existingAuthUser) {
      // Email already in Auth (used by another app) — reuse the auth.users record
      authUserId = existingAuthUser.id;
    } else {
      // Create new auth user
      const { data: newUser, error: createErr } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });
      if (createErr) {
        return new Response(JSON.stringify({ error: createErr.message }), { status: 400, headers: cors });
      }
      authUserId = newUser.user!.id;
    }

    // 4. Insert dashboard_profile
    const { error: profileErr } = await supabaseAdmin
      .from("dashboard_profiles")
      .insert({ user_id: authUserId, email, display_name: display_name || email });

    if (profileErr) {
      return new Response(JSON.stringify({ error: profileErr.message }), { status: 500, headers: cors });
    }

    return new Response(JSON.stringify({ success: true }), { headers: cors });
  }

  // ── DELETE ACCOUNT ────────────────────────────────────────────────────────
  if (action === "delete_user") {
    if (!user_id) {
      return new Response(JSON.stringify({ error: "user_id required" }), { status: 400, headers: cors });
    }

    // Check if other apps have profiles for this user before deleting from Auth
    // Only delete from auth.users if dashboard is the only app using this user
    const otherProfiles = await Promise.all([
      supabaseAdmin.from("profiles").select("id").eq("user_id", user_id).maybeSingle(), // bmi app
      // add other app profile tables here as needed
    ]);

    const usedElsewhere = otherProfiles.some((r) => r.data !== null);

    // Always delete dashboard_profile
    await supabaseAdmin.from("dashboard_profiles").delete().eq("user_id", user_id);

    if (!usedElsewhere) {
      // Safe to delete from auth.users entirely
      const { error: delErr } = await supabaseAdmin.auth.admin.deleteUser(user_id);
      if (delErr) {
        return new Response(JSON.stringify({ error: delErr.message }), { status: 500, headers: cors });
      }
    }

    return new Response(JSON.stringify({ success: true, auth_deleted: !usedElsewhere }), { headers: cors });
  }

  return new Response(JSON.stringify({ error: "Unknown action" }), { status: 400, headers: cors });
});