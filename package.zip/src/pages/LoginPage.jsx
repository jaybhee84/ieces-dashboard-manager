import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import logo from "../image/idm.png";
import "./LoginPage.css";

const ALLOWED_REGISTER_EMAIL = "ieces2024@gmail.com";

export default function LoginPage({ onSuccess, addToast }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState("login");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    try {
      if (mode === "register") {
        const email = identifier;
        if (email.toLowerCase() !== ALLOWED_REGISTER_EMAIL) {
          addToast(
            `Registration is restricted to ${ALLOWED_REGISTER_EMAIL}.`,
            "error",
          );
          return;
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
        });

        if (error) {
          addToast(error.message || "Registration failed", "error");
          return;
        }

        addToast(
          "Registration successful. Check your email to confirm your account.",
          "success",
        );
        setMode("login");
        setIdentifier("");
        setPassword("");
        return;
      }

      const loginEmail = identifier.includes("@")
        ? identifier
        : `${identifier}@ieces.ph`;

      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail,
        password,
      });

      if (error) {
        addToast(error.message || "Login failed", "error");
        return;
      }

      if (data?.session) {
        addToast("Login successful", "success");
        onSuccess(data.session);
      }
    } catch (error) {
      addToast("Unexpected login error", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page-container">
      <div className="login-card">
        <div className="login-brand">
          <img src={logo} alt="IECES IDM Logo" className="login-logo" />
          <p className="muted">Administrator sign in</p>
        </div>

        <div className="login-section">
          <form className="login-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <label htmlFor="identifier">
              {mode === "register" ? "Email" : "Username or email"}
            </label>
            <input
              id="identifier"
              type="text"
              required
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={
                mode === "register"
                  ? "ieces2024@gmail.com"
                  : "admin (or admin@ieces.ph)"
              }
            />
          </div>

          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
          </div>

          {mode === "register" && (
            <div className="register-note">
              Only <strong>ieces2024@gmail.com</strong> may register.
            </div>
          )}

          <div className="form-actions">
            <button type="submit" className="primary-btn" disabled={loading}>
              {loading
                ? mode === "register"
                  ? "Registering…"
                  : "Logging in…"
                : mode === "register"
                  ? "Register"
                  : "Login"}
            </button>
          </div>
        </form>

          <div className="auth-switch">
          {mode === "login" ? (
            <button
              type="button"
              className="auth-toggle"
              onClick={() => {
                setMode("register");
                setIdentifier("");
                setPassword("");
              }}
            >
              Create account
            </button>
          ) : (
            <button
              type="button"
              className="auth-toggle"
              onClick={() => {
                setMode("login");
                setIdentifier("");
                setPassword("");
              }}
            >
              Back to login
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
